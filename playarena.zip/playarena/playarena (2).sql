-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 14, 2024 at 07:14 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `playarena`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL,
  `feedback` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `rating`, `feedback`, `created_at`) VALUES
(1, 'soham', 'bitgamb420@gmail.com', 5, 'This is the best turf booking site ever', '2024-04-14 04:49:48'),
(2, 'playarena', 'playarena@gmail.com', 5, 'Must go for this option , can book turf on the go now!', '2024-04-14 05:05:02');

-- --------------------------------------------------------

--
-- Table structure for table `generate_qr`
--

CREATE TABLE `generate_qr` (
  `id` int(11) NOT NULL,
  `turf_name` varchar(255) DEFAULT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `booking_date` date DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `qr_code_image_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `generate_qr`
--

INSERT INTO `generate_qr` (`id`, `turf_name`, `booking_id`, `user_name`, `booking_date`, `start_time`, `end_time`, `price`, `qr_code_image_path`) VALUES
(1, 'BLIEZ TURF', 35, 'soham', '2024-04-11', '06:00:00', '09:00:00', 5400.00, '../payment/booking_qr_35.png'),
(3, 'BLIEZ TURF', 36, 'sahil', '2024-04-12', '06:00:00', '07:00:00', 1800.00, '../payment/booking_qr_36.png'),
(5, 'Ultimate Turf Football', 38, 'sanjay', '2024-04-12', '06:00:00', '09:00:00', 5400.00, '../payment/booking_qr_38.png'),
(6, 'Suvidhya', 39, 'soham', '2024-04-12', '07:00:00', '11:00:00', 6600.00, '../payment/booking_qr_39.png'),
(7, 'BLIEZ TURF', 40, 'tarun', '2024-04-14', '06:00:00', '07:00:00', 1800.00, '../payment/booking_qr_40.png');

-- --------------------------------------------------------

--
-- Table structure for table `play_admin`
--

CREATE TABLE `play_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `play_admin`
--

INSERT INTO `play_admin` (`id`, `username`, `password`) VALUES
(1, 'playarena', '$2y$10$B8dKFznFaiIqEwe1CSLRCOVbX92krXjAEGs0sY3LKLgLDCL3oooaS');

-- --------------------------------------------------------

--
-- Table structure for table `play_turf`
--

CREATE TABLE `play_turf` (
  `id` int(11) NOT NULL,
  `turf_name` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `time_slot` varchar(255) NOT NULL,
  `size` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `vacancy_status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `play_turf`
--

INSERT INTO `play_turf` (`id`, `turf_name`, `location`, `time_slot`, `size`, `address`, `image`, `vacancy_status`) VALUES
(1, 'Suvidhya Turf', 'Gorai-1', '8 am - 9 pm', '2000 sqft', ' Gorai Link Road, Gorai 1, Borivali West, Mumbai, Maharashtra 400092', '../images/dash2.jpg', '1'),
(2, 'BLIEZ TURF', ' MHB Colony', '8 am - 9 pm', '3000 sqft', ' Pradnya Rd, MHB Colony, Mhada Colony, Borivali West, Mumbai, Maharashtra 400092', '../images/blez_turf.jpg', '1'),
(3, 'Ultimate Turf Football', ' Borivali', '7 am - 9 pm ', '4000 sqft', 'Gorai 1, Borivali, Mumbai, Maharashtra 400091', '../images/ul_turf.jpg', '1'),
(4, 'FootCric Turf', 'Nalanda Academy', '7 am - 9 pm ', '4000 sqft', 'Nalanda Academy, RSC Rd Number 34, near Mangal Murti Hospital Road, Gorai 2, Borivali, W, Mumbai, Maharashtra 400091', '../images/foodcric_turf.jpg', '1');

-- --------------------------------------------------------

--
-- Table structure for table `play_users`
--

CREATE TABLE `play_users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `play_users`
--

INSERT INTO `play_users` (`id`, `username`, `email`, `phone_number`, `password`) VALUES
(1, 'mm', 'mm', 'mm', '$2y$10$yxRB.JQ7/0A9yb7IwvGPneZFSb.lBL9g3/tgpc1SGedzDRc8U7gUG'),
(2, 'harsh', 'harshmhamunkar71@gmail.com', '9221090748', '$2y$10$.zNjf.1B9s7PTsxK37uIpuzfs1uFi2aSrhyx1STMm9NUDPE3aT0ni'),
(3, 'sahil', 'sahilbaddade@gmail.com', '1234567890', '$2y$10$brlk2DuseGRG8cyrXfHy8O.NC/GmwTNWns2xdmtN8DOgMn37PFIGa'),
(4, 'sanjay', 'sanjaymokal25@gmail.com', '9321518299', '$2y$10$fbbnRUR2OIAUkCz/5VtHgekdwJjOXCtoWpIkPodfJbJXetoJIbx/G'),
(7, 'soham', 'bitgamb420@gmail.com', '9137953313', '$2y$10$AfrOntJuah.hAVpnSdrw5.28ezKJ0fJfAJh0KzRYElDqzmUE4N9Ca'),
(10, 'tarun', 'tarun@gmail.com', '8288282828', '$2y$10$IA9X5ATjF6hTFTmv9i0sSuZS8J1sRRhV3lKaqTI7VffxF6tyxybRO'),
(11, 'playarena', 'playarena@gmail.com', '8288282829', '$2y$10$sw5gN.5FmoQm/EJV9uB7ZuDuQ/F5MvqDUZJRl2sYQdleyxH4cktYa');

-- --------------------------------------------------------

--
-- Table structure for table `turf_booking`
--

CREATE TABLE `turf_booking` (
  `booking_id` int(11) NOT NULL,
  `turf_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `booking_date` date DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `payment_status` varchar(255) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `turf_booking`
--

INSERT INTO `turf_booking` (`booking_id`, `turf_id`, `user_id`, `booking_date`, `start_time`, `end_time`, `price`, `payment_status`) VALUES
(30, 1, 1, '2024-04-19', '06:00:00', '08:00:00', 3600.00, 'pending'),
(31, 1, 1, '2024-04-11', '06:00:00', '08:00:00', 3600.00, 'success'),
(32, 1, 1, '2024-04-12', '06:00:00', '01:00:00', 0.00, 'pending'),
(33, 1, 1, '2024-04-13', '06:00:00', '08:00:00', 3600.00, 'success'),
(34, 3, 1, '2024-04-11', '06:00:00', '08:00:00', 3600.00, 'success'),
(35, 2, 1, '2024-04-11', '06:00:00', '09:00:00', 5400.00, 'success'),
(36, 2, 3, '2024-04-12', '06:00:00', '07:00:00', 1800.00, 'success'),
(37, 1, 3, '2024-04-12', '06:00:00', '07:00:00', 1800.00, 'success'),
(38, 3, 4, '2024-04-12', '06:00:00', '09:00:00', 5400.00, 'success'),
(39, 1, 1, '2024-04-12', '07:00:00', '11:00:00', 6600.00, 'success'),
(40, 2, 10, '2024-04-14', '06:00:00', '07:00:00', 1800.00, 'success');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `generate_qr`
--
ALTER TABLE `generate_qr`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `play_admin`
--
ALTER TABLE `play_admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `play_turf`
--
ALTER TABLE `play_turf`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `play_users`
--
ALTER TABLE `play_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone_number` (`phone_number`);

--
-- Indexes for table `turf_booking`
--
ALTER TABLE `turf_booking`
  ADD PRIMARY KEY (`booking_id`),
  ADD KEY `turf_id` (`turf_id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `generate_qr`
--
ALTER TABLE `generate_qr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `play_admin`
--
ALTER TABLE `play_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `play_turf`
--
ALTER TABLE `play_turf`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `play_users`
--
ALTER TABLE `play_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `turf_booking`
--
ALTER TABLE `turf_booking`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `turf_booking`
--
ALTER TABLE `turf_booking`
  ADD CONSTRAINT `turf_booking_ibfk_1` FOREIGN KEY (`turf_id`) REFERENCES `play_turf` (`id`),
  ADD CONSTRAINT `turf_booking_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `play_users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
