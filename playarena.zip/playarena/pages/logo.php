<!-- logo.php -->
<img src="../images/logo.png" alt="Logo">
